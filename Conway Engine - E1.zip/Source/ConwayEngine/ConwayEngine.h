void conwayTransform(int **CellData, int MW, int MH);
int getAliveNeyboors(int **tab, int x, int y, int xmax, int ymax);
int Vivant(int **CellData,int MW,int MH);