#EQUIPE NUMERO 1 : 
CITRINI   Mathias
BOURJALA  Tom
MEGY	  Manon
DEVAUX	  Baptiste

#LANCEMENT DU PROGRAMME
fichier ./Build/conwayApp

#COMPILATION DU PROGRAMME
cd ./Build
1 : make deepclean
2 : make

#SOURCES
dans ./Sources 
les différents éléments dans leurs dossiers respectifs.

>CONTROLES
Molette : Zoomer sur la grille
Clic droit : Se déplacer sur la grille
Clic gauche : Ajouter une cellule
Espace : Raccourcis pause